const express = require('express');
const compression = require('compression');
const fs = require('fs');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

// ─── Translation API config (load from .env if exists) ───────
try {
  const dotenv = require('dotenv');
  dotenv.config();
} catch(e) {}
// Hardcoded fallback for translation env vars if .env missing
if (!process.env.TRANSLATE_API_KEY && fs.existsSync('.env')) {
  try {
    const envContent = fs.readFileSync('.env', 'utf8');
    envContent.split('\n').forEach(line => {
      const match = line.match(/^([A-Z_]+)=(.*)$/);
      if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
    });
  } catch(e) {}
}
const { feishuProTables } = require('./scripts/generate-products-data-table.js');
const {
  runFeishuSyncOnce,
  startDailyFeishuSyncScheduler,
  buildFeishuConfigFromEnv,
  validateFeishuConfig
} = feishuProTables;

// ─── API Server Proxy ───────────────────────────────────────────────
// All API, admin, and upload requests go to KitchenYuKoLiServer.
// Configurable via API_SERVER env var (default: http://127.0.0.1:8000).
const API_SERVER = process.env.API_SERVER || 'http://127.0.0.1:8001';
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();

const apiProxy = createProxyMiddleware({
  target: API_SERVER,
  changeOrigin: true,
  pathFilter: ['/api/cms/**', '/api/translations/**', '/api/nav-config/**', '/admin/**'],
  pathRewrite: { '^/api/translations': '/api/cms/translations' },
  logLevel: process.env.NODE_ENV !== 'production' ? 'warn' : 'silent',
  onError: (err, req, res) => {
    console.error('[proxy] error:', err.message, req.path);
    if (!res.headersSent) res.status(502).json({ error: 'API server unavailable' });
  }
});
app.use(apiProxy);
app.set('trust proxy', 1);

// Strict CSP for main site
// Remove problematic CORS headers after helmet (for non-HTTPS LAN origins)
const REMOVE_COEP = ['Cross-Origin-Embedder-Policy', 'Cross-Origin-Opener-Policy', 'Origin-Agent-Cluster'];
app.use((req, res, next) => {
  const origWriteHead = res.writeHead;
  res.writeHead = function(...args) {
    REMOVE_COEP.forEach(h => this.removeHeader(h));
    return origWriteHead.apply(this, args);
  };
  next();
});

// Rate limiting to prevent abuse
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5000, // limit each IP to 5000 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Skip rate limiting for admin, API, and static assets (all have their own protections)
    return req.path.startsWith('/admin') ||
           req.path.startsWith('/api/') ||
           req.path.startsWith('/assets/') ||
           req.path.match(/\.(js|css|png|jpg|jpeg|gif|svg|webp|ico|woff2?|ttf|eot|mp4|webm)$/);
  }
});

app.use(limiter);

// Enable gzip/brotli compression with optimized settings
app.use(compression({
  level: 6, // Good balance between compression and speed
  threshold: 1024, // Only compress responses larger than 1KB
  filter: (req, res) => {
    if (req.headers['x-no-compression']) {
      return false;
    }
    // Don't compress already compressed assets
    if (req.path.match(/\.(gz|br|zip|rar|7z)$/)) {
      return false;
    }
    return compression.filter(req, res);
  }
}));

// Allowed origins for CORS (same-origin + production domain)
const ALLOWED_ORIGINS = new Set([
  'https://www.yukoli.com',
  'https://yukoli.com',
]);

// Additional security and performance headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');

  // CORS — allow requests from same origin and production domain
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.has(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');
    res.setHeader('Access-Control-Max-Age', '86400'); // 24h preflight cache
    res.setHeader('Vary', 'Origin');
  }

  // Handle OPTIONS preflight immediately — no further processing needed
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // Remove server header for security
  res.removeHeader('X-Powered-By');

  next();
});

// Advanced caching middleware with content-based cache keys
app.use((req, res, next) => {
  // ─── Development: disable ALL HTTP caching for live reload ───
  if (process.env.NODE_ENV !== 'production') {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Surrogate-Control', 'no-store');
    return next();
  }
  next();
});

// Production-only caching middleware with content-based cache keys
app.use((req, res, next) => {
  const isAsset = req.path.match(/\.(css|js|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot|json)$/);
  const isTranslation = req.path.includes('/translations/');
  const isHtmlPage = req.path.match(/\.html$/i) || req.path === '/' || req.path === '/index.html';

  if (req.path === '/' || req.path === '/index.html') {
    // Main HTML entry - no cache for dev
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Vary', 'Accept-Encoding');
  } else if (isHtmlPage) {
    // All HTML pages - no cache for dev
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Vary', 'Accept-Encoding');
  } else if (isTranslation) {
    // Translation files - no cache for dev
    res.setHeader('Cache-Control', 'no-cache');
  } else if (isAsset) {
    // Static assets - long-term cache with immutable
    const maxAge = 60 * 60 * 24 * 30; // 30 days
    res.setHeader('Cache-Control', `public, max-age=${maxAge}, immutable`);
    res.setHeader('Expires', new Date(Date.now() + maxAge * 1000).toUTCString());
  } else {
    // Other routes - short cache
    res.setHeader('Cache-Control', 'public, max-age=300, must-revalidate'); // 5 minutes
  }

  next();
});

// CMS admin panel — now served by KitchenYuKoLiServer via /admin proxy
// (local admin removed — all data/API goes through API_SERVER)

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// ═══ Trailing slash redirect for known route directories
// Handles /home → /home/, /products → /products/, etc.
app.use((req, res, next) => {
  // Skip if path already ends with /
  if (req.path.endsWith('/')) return next();

  var cleanPath = req.path.replace(/\/+$/, '');
  if (cleanPath && cleanPath !== '/') {
    var dirPath = path.join(__dirname, 'dist', cleanPath);
    try {
      if (require('fs').statSync(dirPath).isDirectory()) {
        var target = cleanPath + '/' + (req.url.slice(req.path.length) || '');
        return res.redirect(301, target);
      }
    } catch (e) {
      // not a directory, continue
    }
  }
  next();
});

// Serve static files with advanced optimizations
// IMPORTANT: Disable index option to prevent Express from serving home/index.html
app.use(express.static(path.join(__dirname, 'dist'), {
  etag: true,
  lastModified: true,
  maxAge: 0, // Let Cache-Control header handle caching
  index: false, // Disable default index file serving - we handle it explicitly
  setHeaders: (res, path) => {
    // Development: no cache at all
    if (process.env.NODE_ENV !== 'production') {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      return;
    }
    const ext = path.split('.').pop().toLowerCase();

    // Set specific cache headers based on file type
    // Only allow long-term immutable caching for assets that include a content hash
    const isHashedAsset = /[.-][a-f0-9]{8,}\./i.test(path);

    if (['css', 'js'].includes(ext)) {
      if (isHashedAsset) {
        res.setHeader('Cache-Control', 'public, max-age=31536000, immutable'); // 1 year for hashed assets
      } else {
        // Non-hashed JS/CSS should be short-lived to avoid stale clients
        res.setHeader('Cache-Control', 'public, max-age=300, must-revalidate'); // 5 minutes
      }
    } else if (['png', 'jpg', 'jpeg', 'gif', 'ico', 'svg', 'woff', 'woff2'].includes(ext)) {
      // Images: reasonable mid-term caching
      res.setHeader('Cache-Control', 'public, max-age=2592000'); // 30 days
    } else if (ext === 'json') {
      // JSON (e.g. translations) should be short-lived unless versioned
      res.setHeader('Cache-Control', 'public, max-age=300, must-revalidate'); // 5 minutes
    }

    // Removed incorrect preload hint for translations
  }
}));

// Explicit root route - serve SPA entry with SPA navigation
// The entry handler script in index.html will handle device-specific routing
// without page redirect, maintaining header/body/footer structure
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// SPA fallback with proper 404 handling
// Known SPA routes — always serve the root SPA shell, let the frontend router handle them
const SPA_ROUTES = ['/home', '/products', '/applications', '/cases', '/profit-calculator', '/products/compare', '/about', '/contact', '/quote',
  '/support', '/news', '/thank-you', '/landing',
  // New structure (P0 trust page first)
  // New structure (P1 high-value pages)
  '/applications/chain-restaurant',  '/applications/central-kitchen',
  // New structure (P2 volume pages)
  '/applications/small-restaurant', '/applications/menu-lab', '/applications/canteen',
  '/applications/cloud-kitchen',
  // Product detail (dynamic PDP)
  '/products/detail',
  // Support sub-pages
  '/support/installation', '/support/warranty', '/support/spare-parts', '/support/training', '/support/faq',
  // ROI legacy redirect
  '/roi'];

app.get('*', (req, res) => {
  // Never intercept API routes
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });

  var fs = require('fs');

  // Only look inside dist/ — never expose project root files (scripts/, .env, etc.)
  var filePath = path.join(__dirname, 'dist', req.path);

  // Check if it's an exact file match (CSS, JS, images, etc.)
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return res.sendFile(filePath);
  }

  // Webpack outputs pages under dist/pages/ — SPA router fetches /products/index-pc.html
  // but the file lives at dist/pages/products/index-pc.html
  var pagesFilePath = path.join(__dirname, 'dist', 'pages', req.path);
  if (fs.existsSync(pagesFilePath) && fs.statSync(pagesFilePath).isFile()) {
    return res.sendFile(pagesFilePath);
  }

  // Check if the path matches a known SPA route (with or without trailing slash)
  // Also match sub-paths like /products/炒菜机/ → matches /products
  var cleanPath = req.path.replace(/\/+$/, '') || '/';
  var isSpaRoute = SPA_ROUTES.includes(cleanPath) ||
    SPA_ROUTES.some(function(route) { return cleanPath.startsWith(route + '/'); });
  if (isSpaRoute) {
    return res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  }

  // Check if path is a directory with index.html (e.g. /some/route/)
  var indexPath = path.join(__dirname, 'dist', req.path, 'index.html');
  if (fs.existsSync(indexPath) && fs.statSync(indexPath).isFile()) {
    res.sendFile(indexPath);
  } else {
    // Also try dist/pages/ for directory index.html
    var pagesIndexPath = path.join(__dirname, 'dist', 'pages', req.path, 'index.html');
    if (fs.existsSync(pagesIndexPath) && fs.statSync(pagesIndexPath).isFile()) {
      res.sendFile(pagesIndexPath);
    } else if (process.env.NODE_ENV !== 'production') {
      // Dev fallback: serve from src/ for files not yet built (e.g. lang JSON, images)
      var srcPath = path.join(__dirname, 'src', req.path);
      if (fs.existsSync(srcPath) && fs.statSync(srcPath).isFile()) {
        res.sendFile(srcPath);
      } else {
        res.sendFile(path.join(__dirname, 'dist', 'index.html'));
      }
    } else {
      // For unknown routes, serve root SPA shell (SPA router will show 404 if needed)
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    }
  }
});

// Global error handling middleware
app.use((err, req, res, _next) => {
  console.error('Server error:', err);

  // Don't leak error details in production
  const isDevelopment = process.env.NODE_ENV !== 'production';

  res.status(err.status || 500).json({
    error: isDevelopment ? err.message : 'Internal Server Error',
    ...(isDevelopment && { stack: err.stack })
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not Found' });
});

const PORT = process.env.PORT || 3099;
const SSL_PORT = process.env.SSL_PORT ? parseInt(process.env.SSL_PORT) : 3000;
const ENABLE_SSL = SSL_PORT > 0;
const https = require('https');
const sslOptions = {
  key: fs.readFileSync('/Users/chee/certs/192.168.3.181-key.pem'),
  cert: fs.readFileSync('/Users/chee/certs/192.168.3.181-new.pem'),
};

// Start server with error handling
const server = app.listen(PORT, (err) => {
  if (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }

  console.log(`🚀 Optimized static server running on http://localhost:${PORT}`);
  console.log('📦 Compression: Enabled');
  console.log('🔒 Security headers: Enhanced');
  console.log('💾 Advanced caching: Enabled');
  console.log('🛡️  Rate limiting: Enabled');
  console.log(`🏥 Health check: http://localhost:${PORT}/health`);

  if (process.env.NODE_ENV === 'development') {
    console.log('🔧 Development mode: Error details enabled');
  }

  const feishuConfig = buildFeishuConfigFromEnv();
  if (validateFeishuConfig(feishuConfig)) {
    runFeishuSyncOnce()
      .then((result) => {
        console.log('[feishu-sync] initial sync finished:', JSON.stringify(result));
      })
      .catch((err) => {
        console.error('[feishu-sync] initial sync failed:', err.message);
      });
  } else {
    console.log('[feishu-sync] initial sync skipped: missing FEISHU env config');
  }

  startDailyFeishuSyncScheduler();
  console.log('[feishu-sync] daily scheduler enabled (04:00)');

  // Start HTTPS server (only if SSL_PORT > 0 — skip when behind reverse proxy)
  if (ENABLE_SSL) {
    const httpsServer = https.createServer(sslOptions, app);
    httpsServer.listen(SSL_PORT, (err) => {
      if (err) { console.error('Failed to start HTTPS server:', err); return; }
      console.log(`🔒 HTTPS running on https://192.168.3.181:${SSL_PORT}`);
    });
  }
});

// Graceful shutdown with connection draining
const gracefulShutdown = (signal) => {
  console.log(`Received ${signal}, shutting down gracefully`);

  server.close((err) => {
    if (err) {
      console.error('Error during server shutdown:', err);
      process.exit(1);
    }

    console.log('Server closed successfully');
    process.exit(0);
  });

  // Force shutdown after 10 seconds
  setTimeout(() => {
    console.error('Forced shutdown after timeout');
    process.exit(1);
  }, 10000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

module.exports = app;
